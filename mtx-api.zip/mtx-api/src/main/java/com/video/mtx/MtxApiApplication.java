package com.video.mtx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtxApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtxApiApplication.class, args);
	}

}
